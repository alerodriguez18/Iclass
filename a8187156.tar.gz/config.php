<?php

/**
 * Database config variables
 */
define("DB_HOST", "mysql2.000webhost.com");
define("DB_USER", "a8187156_diego");//cambiar por el nombre de usuario definido en la configuracion de la BD.
define("DB_PASSWORD", "diego123");//Modificar por el password elegido
define("DB_DATABASE", "a8187156_rsa");//Nombre de la base de datos reemplazar si se utilizo otro diferente al mencionado en el tutorial.
?>
