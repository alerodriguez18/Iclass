<?php
session_start();
session_unset();
session_destroy();
echo "<meta content='0;URL=index.php' http-equiv='REFRESH'> </meta>";
?>




