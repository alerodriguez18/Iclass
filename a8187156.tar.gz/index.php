<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<script language="JavaScript" src="md5.js"></script>
<script  language="JavaScript">
function encriptar(){
hash = calcMD5(document.getElementById('contrasena').value);
document.getElementById('contrasena').value=hash;
//alert(hash);
document.form1.submit();
return 0;
}
</script>


<style type="text/css">
<!--
#Layer1 {
	position:absolute;
	width:200px;
	height:115px;
	z-index:1;
	left: 13px;
	top: 11px;
}
#Layer2 {
	position:absolute;
	width:152px;
	height:115px;
	z-index:1;
	top: 13px;
	left: 7px;
border:solid 1px #ddd;
-moz-box-shadow:7px 8px 2px #333;
-webkit-box-shadow:7px 8px 2px #333;
box-shadow:5px 6px 1px #333;
}
#Layer3 {
	position:absolute;
	width:1071px;
	height:97px;
	z-index:2;
	left: 178px;
	top: 13px;
}
#Layer4 {
	position:absolute;
	width:1139px;
	height:115px;
	z-index:3;
	left: 81px;
	top: 558px;
}
#Layer5 {
	position:absolute;
	width:200px;
	height:18px;
	z-index:4;
	left: 960px;
	top: 327px;
}
#Layer7 {
	position:absolute;
	width:1146px;
	height:115px;
	z-index:1;
	top: 527px;
	left: 94px;
}
.Estilo2 {color: #FFFFFF}
-->
</style>
</head>
<body bgcolor="2c4762">
<div id="Layer2" ><img src="Logo.jpg" width="150" height="110"  /></div>
<p>&nbsp;</p>
<div id="Layer3">
  <table border="0" cellpadding="0" cellspacing="0" id="header"  >
    <tbody>
      <tr>
        <td id="topright"><br />
          <span class="Estilo2">En el �mbito educativo, el ejercicio asincr�nico propio de 
los foros virtuales permite a los estudiantes articular sus ideas
 y opiniones desde distintas fuentes de discusi�n, promoviendo el 
aprendizaje a trav�s de varias formas de interacci�n distribuidas en espacios
 y tiempos diferentes. Los foros son una gran fuente para solucionar problemas, 
tienen informaci�n muy valiosa y normalmente los temas que se presentan nos aclaran muchas dudas, 
las ventajas son muchas ya que es una forma gratuita de aprender y as� de esta forma el poder tener 
clases en l�nea por medio  las nuevas tecnolog�as para el aprendizaje de los alumnos y ayuda a los profesores.</span>		  </span></td>
      </tr>
    </tbody>
  </table>
</div>
<p>&nbsp; </p>
<p>&nbsp;</p>
<p>&nbsp;</p>
<hr>
<p>&nbsp;</p>
<div id="Layer5"><a href="Registro.html" class="Estilo2">REGISTRARME</a></div>

<form name="form1" method="post" action="validacion.php" >
<center>
<center> <strong>SOLO USUARIOS REGISTRADOS </strong></center>
<div id="d1" style="background-color:#FFFFFF ;height:150px; width:200px; border: 5px solid #000000;>
<table width="378" height="75" border="1"  >
  <tr>
    <td width="166">USUARIO</td>
	
    <td width="98"><input type="text"  name="usuario" id="usuario"/></td>
  </tr>
  <tr>
    <td>CONTRASE&Ntilde;A</td>
    <td><input type="password" name="contrasena" id="contrasena"/></td>
  </tr>
   <tr>
    <td>
	  <p>
	    <input type="button" onclick= "encriptar()" id="Button" value="Login" />
		
	      </p></td>	
		  
  </tr>
 
</table>


</div>
<hr>

</center>
</form>

<div align="center"><a href="http://contadores.gratisparaweb.com" target="_blank"><img src="http://contadores.gratisparaweb.com/imagen.php?contador=82&id2=26682" alt="Contadores" border="0"></a><br><br></map></a></div>
<div id="Layer7">
  <table border="0" cellpadding="0" cellspacing="0" id="header"  >
    <tbody>
      <tr>
        <td id="topright"><br />
<center>          <span class="Estilo2">
Iclass es una p�gina opcional que nos permitir� brindar tiempo y espacio para toda la comunidad educativa 
en general funcionando tambi�n como una clase de foro para los alumnos sin fines de lucro. Para mayor informaci�n favor de 
comunicarse por medio del registro a esa p�gina web o a nuestra pagina de <a href='http://www.Facebook.com/IclassUpvm' target=_blank><font color=FFFFFF>Facebook</font></a> . Iclass fue fundado por alumnos de la carrera de 
Ingenier�a en Inform�tica de la Universidad Polit�cnica del Valle de M�xico. Si usted desea hacer alguna donaci�n  favor de comunicarse
 a la siguiente direcci�n de correo electr�nico iclassupvm@gmail.com.mx . Todos los derechos reservados..</span>	</center>	  </span></td>
      </tr>
    </tbody>
  </table>
</div>


</body>
</html>
